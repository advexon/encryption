"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import TextEncryption from "./text-encryption"
import FileEncryption from "./file-encryption"
import AlgorithmInfo from "./algorithm-info"

export default function EncryptionApp() {
  const [activeTab, setActiveTab] = useState<string>("text")

  return (
    <div className="max-w-4xl mx-auto">
      <Tabs defaultValue="text" onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="text">Text Encryption</TabsTrigger>
          <TabsTrigger value="file">File Encryption</TabsTrigger>
        </TabsList>

        <Card className="border border-gray-800 bg-gray-950 shadow-xl">
          <CardContent className="p-6">
            <TabsContent value="text" className="mt-0">
              <TextEncryption />
            </TabsContent>
            <TabsContent value="file" className="mt-0">
              <FileEncryption />
            </TabsContent>
          </CardContent>
        </Card>
      </Tabs>

      <div className="mt-8">
        <AlgorithmInfo />
      </div>
    </div>
  )
}
